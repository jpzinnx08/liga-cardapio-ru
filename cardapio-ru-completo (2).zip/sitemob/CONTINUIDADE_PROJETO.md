# CONTINUIDADE DO PROJETO — Cardápio RU (Ionic 9 + Angular Standalone + Firebase)

## Objetivo
Sistema de avaliação do Restaurante Universitário: login, cardápio com pratos (comum/vegano), filtros,
avaliação 1–5 estrelas + comentário gravada no Firestore, tela de avaliações, destaque do prato mais bem avaliado,
e (mantido da fase anterior) pedido + comprovante em PDF.

## Tecnologias
Ionic 9 (`@ionic/angular`, import direto, sem `/standalone`), Angular standalone, TypeScript, Firebase Auth + Firestore (SDK modular), jsPDF.

## Estrutura relevante (src/app)
- `firebase.ts` — instância única do Firebase (usa `environments/firebase.config.ts`).
- `models/` — `prato.model.ts` (Prato, PratoBase, OpcaoFiltro, CategoriaPrato, FiltroCategoria), `avaliacao.model.ts` (Avaliacao, NovaAvaliacao), `index.ts`.
- `services/` — `prato.service.ts` (regras + Firestore), `auth.service.ts`, `order.service.ts`.
- `components/` — `prato-card` (@Input prato/selecionado/destaque; @Output avaliar/selecionar), `avaliacao-modal` (@Input prato/enviando; @Output enviar/cancelar), `avaliacao-card`, `estrelas`, `topbar`.
- `pages/` — `login`, `menu` (Cardápio), `avaliacoes`, `order`.
- `firestore.rules` (raiz) — regras sugeridas para publicar no Firebase.

## Concluído (implementado e compilando)
- S2 Models + Service: pasta models, interfaces tipadas, PratoService (`providedIn: 'root'`) com lista de pratos, filtro por categoria, disponibilidade (`definirDisponibilidade`), média e quantidade calculadas, lista de avaliações.
- S3 Input/Output: prato-card (filho) → página pai trata `avaliar` e `selecionar`; modal → pai trata `enviar` e `cancelar`.
- S4 Firestore: `addDoc` na coleção `avaliacoes` (pratoId, nomePrato, nota, comentario, usuarioId, nomeUsuario, data=serverTimestamp); leitura em tempo real com `onSnapshot` (média/quantidade/lista atualizam sozinhas). Validação da nota (1–5) no modal e no service. Toast de sucesso/erro.
- S5 Visual: identidade verde, toolbar "RU Avalia", cards arredondados, emojis de comida, estrelas, layout responsivo (grid), destaque 🏆 do prato mais bem avaliado (calculado com avaliações reais).
- Mantido: login/cadastro/Google, pedido (FAZER PEDIDO) e PDF.

## Verificação feita
- `ngc` (checagem de tipos + templates): sem erros.
- `ng build --configuration production`: OK.
- `ionic serve`: sobe e responde HTTP 200.

## NÃO verificado (precisa das credenciais do dono do projeto)
- Gravação real no Firestore, login Firebase e atualização em tempo real: dependem do `firebase.config.ts` preenchido, do Firestore criado e das regras publicadas. Não foi possível testar aqui.
- Interface renderizada no navegador (sem navegador disponível no ambiente de desenvolvimento): conferir visualmente.

## Pendências / observações
- Nenhum requisito deixado de fora, mas o item acima (teste real com Firebase) precisa ser feito pelo usuário.
- Sem avaliações no Firestore, as médias aparecem como "Sem avaliações ainda" (não há dados fictícios gravados).
- Se aparecer "permission-denied": publicar `firestore.rules`.

## Próxima etapa sugerida
1. Preencher `src/environments/firebase.config.ts`; ativar Auth (E-mail/senha e Google); criar Firestore; publicar `firestore.rules`.
2. Testar: login → avaliar um prato → conferir documento em `avaliacoes` no console → ver média/quantidade e a tela Avaliações.
3. Ajustes visuais finos, se necessário.

## Para continuar em nova conversa
"Leia primeiro CONTINUIDADE_PROJETO.md, analise o estado atual dos arquivos, não repita o que já está concluído e continue da próxima etapa, mantendo as decisões de arquitetura."

## Atualização — fechamento dos requisitos
- Toolbar/login agora "Cardápio RU"; filtro "Veg / Comum / Todos".
- Filtro, seleção, bandeja, total e confirmação movidos para `PratoService` (página só repassa e exibe).
- Aviso (toast) ao tentar escolher prato esgotado.
- Novo componente `bandeja-modal` (confirmação com lista + total) e model `pedido.model.ts`.
- `confirmarBandeja()` grava documento NOVO em `pedidos`: usuarioId, nomeUsuario, pratos, total, status='confirmado', codigo, data (serverTimestamp). Regras em `firestore.rules`.
- Ainda NÃO testado com Firebase real nem compilado (sem node_modules no ambiente de edição).
