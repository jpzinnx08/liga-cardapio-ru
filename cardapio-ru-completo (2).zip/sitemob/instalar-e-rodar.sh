#!/bin/sh
# Linux / Mac / WSL
cd "$(dirname "$0")"
echo "Node: $(node -v)  npm: $(npm -v)  sistema: $(uname -s) $(uname -m)"
rm -rf node_modules package-lock.json .angular www
npm cache clean --force
npx --yes npm@latest install --include=optional --no-audit --no-fund || exit 1
node verificar.mjs || exit 1
npx ionic serve
