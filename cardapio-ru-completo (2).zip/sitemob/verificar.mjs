// Confere se os binários nativos do Angular foram instalados corretamente.
try {
  await import('rolldown');
  await import('oxc-parser');
  console.log('Binarios nativos OK');
} catch (e) {
  console.error('FALHOU: binario nativo ->', e.message);
  process.exit(1);
}
