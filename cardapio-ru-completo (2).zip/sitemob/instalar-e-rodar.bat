@echo off
cd /d "%~dp0"
echo Node:
node -v
echo npm:
call npm -v
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /f /q package-lock.json
if exist .angular rmdir /s /q .angular
call npm cache clean --force
call npx --yes npm@latest install --include=optional --no-audit --no-fund
if errorlevel 1 goto erro
node verificar.mjs
if errorlevel 1 goto erro
call npx ionic serve
goto fim
:erro
echo.
echo ERRO na instalacao. Copie as mensagens acima e envie para ajuda.
:fim
pause
